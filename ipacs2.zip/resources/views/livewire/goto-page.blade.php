{{ $paginator->onEachSide(1)->links('livewire::tailwind') }}
