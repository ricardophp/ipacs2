<div>
    <textarea wire:model="content" rows="10" cols="50"></textarea>
    <br>
    <button wire:click="generatePDF">Generar PDF</button>
</div>
